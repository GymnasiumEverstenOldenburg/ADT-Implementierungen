# ADT Neuimplementierung

Implementierung folgenden Klassen nach den Vorgaben des KCs der gymnasialen Oberstufe (Niedersachsen):
- BinTree
- DynArray
- Queue
- Stack

Aktuelle Versionen dieser Files können auf GitHub gefunden werden.

https://github.com/GymnasiumEverstenOldenburg/ADT-Implementierungen


Copyright (c) 2024 Alexander Reimer <alexander.reimer2357@gmail.com>, Yannick Weigert <yannick@gelbeinhalb.com>
https://github.com/GymnasiumEverstenOldenburg/ADT-Implementierungen/blob/main/LICENSE
